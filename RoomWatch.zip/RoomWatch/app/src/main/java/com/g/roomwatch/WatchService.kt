package com.g.roomwatch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.webkit.WebView
import android.webkit.WebViewClient
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Cfg {
    const val CHECK_IN = "05/14/2027"
    const val CHECK_OUT = "05/16/2027"
    const val INTERVAL_MIN = 10L
    const val URL =
        "https://www.marriott.com/reservation/availabilitySearch.mi?isSearch=true" +
        "&propertyCode=BWIBD&fromDate=$CHECK_IN&toDate=$CHECK_OUT" +
        "&numberOfRooms=1&numberOfGuests=2&roomCount=1&guestCount=2"
    val QUEENS = Regex("2 queen|two queen|double queen")
    val VIEW = Regex("youth field|field view|stadium view")
}

object Alerts {
    const val CH_WATCH = "watch"
    const val CH_ALERT = "alert"

    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_WATCH, "Watcher status", NotificationManager.IMPORTANCE_LOW)
        )
        val a = NotificationChannel(CH_ALERT, "Room alerts", NotificationManager.IMPORTANCE_HIGH)
        a.enableVibration(true)
        a.vibrationPattern = longArrayOf(0, 600, 300, 600, 300, 600, 300, 600)
        a.setSound(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        nm.createNotificationChannel(a)
    }

    fun fire(c: Context, title: String, text: String, id: Int) {
        val open = PendingIntent.getActivity(
            c, 0, Intent(Intent.ACTION_VIEW, Uri.parse(Cfg.URL)), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        c.getSystemService(NotificationManager::class.java).notify(id, n)
    }
}

class WatchService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var started = false
    private var fails = 0
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun ongoing(text: String): Notification =
        Notification.Builder(this, Alerts.CH_WATCH)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Room watcher running")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun status(text: String) {
        val stamp = SimpleDateFormat("MMM d h:mm a", Locale.US).format(Date())
        val msg = "$stamp - $text"
        getSharedPreferences("s", 0).edit().putString("last", msg).apply()
        getSystemService(NotificationManager::class.java).notify(1, ongoing(msg))
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        Alerts.channels(this)
        val n = ongoing("Starting...")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
        if (!started) {
            started = true
            wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "roomwatch:cpu")
            wl?.acquire()
            h.post { check() }
        }
        return START_STICKY
    }

    private fun check() {
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        var done = false
        val finish = { text: String? ->
            if (!done) {
                done = true
                wv.stopLoading()
                wv.destroy()
                handle(text)
            }
        }
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, u: String) {
                h.postDelayed({
                    if (!done) v.evaluateJavascript("document.body.innerText") { r -> finish(r) }
                }, 10000)
            }
        }
        h.postDelayed({ finish(null) }, 90000)
        wv.loadUrl(Cfg.URL)
    }

    private fun handle(raw: String?) {
        val t = raw?.lowercase(Locale.US) ?: ""
        val blocked = t.length < 300 || "access denied" in t || "unusual activity" in t
        var delay = Cfg.INTERVAL_MIN * 60_000 + (0..90_000).random()

        if (blocked) {
            fails++
            status("Check failed or blocked ($fails in a row)")
            if (fails == 3) {
                Alerts.fire(
                    this, "Watcher is being blocked",
                    "Marriott blocked 3 checks in a row. Check manually.", 3
                )
            }
        } else {
            fails = 0
            val sold = listOf(
                "no rooms available", "sold out", "not available for your dates", "unavailable for"
            ).any { it in t }
            val match = Cfg.QUEENS.containsMatchIn(t) && Cfg.VIEW.containsMatchIn(t) && !sold
            if (match) {
                status("ROOM AVAILABLE")
                Alerts.fire(
                    this, "ROOM AVAILABLE - BOOK NOW",
                    "Double queen / youth field view ${Cfg.CHECK_IN} - ${Cfg.CHECK_OUT}", 2
                )
                delay = 5 * 60_000L
            } else {
                status("No room yet")
            }
        }
        h.postDelayed({ check() }, delay)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        wl?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
