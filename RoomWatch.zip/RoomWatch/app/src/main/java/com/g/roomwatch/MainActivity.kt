package com.g.roomwatch

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(48, 120, 48, 48)

        val title = TextView(this)
        title.text = "Ripken Room Watch\nCourtyard Aberdeen\n${Cfg.CHECK_IN} - ${Cfg.CHECK_OUT}\nDouble queen, youth field view"
        title.textSize = 20f
        col.addView(title)

        status = TextView(this)
        status.textSize = 16f
        status.setPadding(0, 32, 0, 32)
        col.addView(status)

        fun btn(label: String, action: () -> Unit) {
            val bt = Button(this)
            bt.text = label
            bt.setOnClickListener { action() }
            col.addView(bt)
        }

        btn("Start watching") { startWatch() }
        btn("Stop") {
            stopService(Intent(this, WatchService::class.java))
            getSharedPreferences("s", 0).edit().putString("last", "Stopped").apply()
            refresh()
        }
        btn("Send test alert") {
            Alerts.channels(this)
            Alerts.fire(this, "Test alert", "Alerts are working.", 9)
        }
        btn("Allow background use (battery)") {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        }
        btn("Open Marriott search") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Cfg.URL)))
        }
        btn("Refresh status") { refresh() }

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        status.text = getSharedPreferences("s", 0).getString("last", "Not started")
    }

    private fun startWatch() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        startForegroundService(Intent(this, WatchService::class.java))
        status.text = "Starting..."
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        startWatch()
    }
}
